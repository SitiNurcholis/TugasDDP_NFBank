data_tf = open("transfer.txt")
data_ns = open("nasabah.txt")
data_mentah = []
data_transfer = []
data_a = []
data_b = []
data_c = []
data_rekening = []
data_nama = []
data_saldo = []
for d in data_tf: # file dijadikan 1 list
    data_mentah.append(d.strip())
for e in data_mentah:   # list di pisahkan memnjadi beberapa list atau multilist
    data_transfer.append(e.split(","))
for f in range(len(data_transfer)): # mengilangkan redudansi data
  if data_transfer[f][1] not in data_a:
    data_a.append(data_transfer[f][1])
for g in data_ns:    # file nasabah dijadikan 1 list
    data_b.append(g.strip())
for h in data_b:    
    data_c.append(h.split(","))
for i in range(len(data_c)):
    data_rekening.append(data_c[i][0])
    data_nama.append(data_c[i][1])
    data_saldo.append(eval(data_c[i][2]))
data_tunai = dict(zip(data_rekening, data_saldo))
data_nasabah = dict(zip(data_rekening, data_nama))
def menu():
    print("Menu: ")
    print("[1] Buka Rekening Bank\n[2] Setoran Tunai\n[3] Tarik Tunai\n[4] Transfer\n[5] Lihat Daftar Transfer\n[6] Cek Saldo\n[7] Keluar")
print("----- SELAMAT DATANG DI NF BANK -----")
menu()
while True: 
    pilih = input("Masukkan menu pilihan anda: ")
    if pilih == '1':
        print("--- PEMBUKAAN REKENING NASABAH BARU NF BANK ---")
        nama = input("Masukkan nama anda: ")
        setoran = eval(input("Masukkan Setoran Awal: "))
        import random, string
        no_rek =  "REK" + ''.join(random.choice(string.digits) for _ in range(3))
        print("Pembukaan dengan nomor rekening", no_rek, "atas nama", nama, "berhasil.\n")
        data_nama.append(nama)
        data_saldo.append(setoran)
        data_rekening.append(no_rek)
        data_tunai[no_rek] = setoran
        data_nasabah[no_rek] = nama
        menu()
    elif pilih == '2':
        print("--- SETORAN TUNAI ---")
        rek = input("Masukkan nomor rekening: ")
        nominal = eval(input("Masukkan nominal yang akan disetor: "))
        if rek.upper() in data_rekening:
            print("Setoran tunai sebesar", nominal, "ke rekening", rek, "berhasil.\n")
            tambah_saldo = data_tunai[rek.upper()] + nominal
            data_tunai[rek.upper()] = tambah_saldo
        else:
            print("Nomor rekening tidak terdaftar. Setoran tunai gagal.\n")
        menu()
    elif pilih == '3':
        print("--- TARIK TUNAI ---")
        rek = input("Masukkan nomor rekening: ")
        nominal = eval(input("Masukkan nominal yang akan diambil: "))
        if rek.upper() in data_rekening:
            if nominal < data_tunai[rek.upper()]:
                min_saldo = data_tunai[rek.upper()]-nominal
                data_tunai[rek.upper] = min_saldo
                print("Tarik tunai sebesar", nominal, "dari rekening", rek, "berhasil.\n")
                data_tunai[rek.upper()] = min_saldo
            else:
                print("Saldo Tidak mencukupi.\n")
        else:
            print("Nomor rekening tidak terdaftar. Tarik tunai gagal.\n")
        menu()
    elif pilih == '4':
        print("--- TRANSFER ---")
        rek = input("Masukkan nomor rekening sumber: ")
        rek_tujuan = input("Masukkan nomor rekening tujuan: ")
        nominal = eval(input("Masukkan nominal yang akan ditransfer: "))
        if rek.upper() in data_rekening:
            if rek_tujuan.upper() in data_rekening:
                if nominal <= data_tunai[rek.upper()]:
                    tambah_saldo = data_tunai[rek_tujuan.upper()]+nominal
                    min_saldo = data_tunai[rek.upper()]-nominal
                    data_tunai[rek.upper()] = min_saldo
                    data_tunai[rek_tujuan.upper()] = tambah_saldo
                    print("Transfer sebesar", nominal, "dari rekening", rek, "ke rekening" , rek_tujuan,"berhasil.\n")
                    import random, string
                    tf = "TRF" + ''.join(random.choice(string.digits) for _ in range(3))
                    data_transfer.append([tf, rek.upper(), rek_tujuan.upper(), nominal])
                    data_a.append(rek.upper())
                else:
                    print("Saldo Tidak mencukupi. \n")
            else:
                print("Nomor rekening tujuan tidak terdaftar. Transfer gagal.\n")
        else:
            print("Nomor rekening sumber tidak terdaftar. Transfer gagal.\n")
        menu()
    elif pilih == '5':
        print("--- LIHAT DATA TRANSFER ---")
        rek = input("Masukkan nomor rekening sumber transfer: ")
        if rek.upper() in data_rekening:
          if rek.upper() in data_a:
                for ldt in range(len(data_transfer)):
                    if rek.upper() == data_transfer[ldt][1]:
                        print(data_transfer[ldt][0], data_transfer[ldt][1], data_transfer[ldt][2], data_transfer[ldt][3])
                print("\n")
          else:
            print("Tidak ada data yang ditampilkan.\n")
        else:
            print("Nomor rekening sumber tidak terdaftar.\n")
        menu()
    elif pilih == '6':
        print("--- CEK SALDO ---")
        rek = input("Masukkan nomor rekening Anda: ")
        if rek.upper() in data_rekening:
            print("Saldo dengan nomor rekening ", rek, "sebesar ", data_tunai[rek.upper()])
            print("\n")
        else:
            print("Nomor rekening yang Anda masukkan salah. Silahkan coba lagi.\n")
        menu()
    elif pilih == '7':
        print("--- Terima kasih atas kunjungan anda ---")
        nasabah = open("nasabah.txt", "+w")
        for hapus in range(len(data_rekening)):
            nasabah.write(str(data_rekening[hapus])+ "," + str(data_nama[hapus]) + "," + str(data_tunai[data_rekening[hapus]])+ "\n")
        transfer = open("transfer.txt", "+w")
        for hapus in range(len(data_transfer)):
            transfer.write(str(data_transfer[hapus][0])+","+str(data_transfer[hapus][1])+","+str(data_transfer[hapus][2])+","+str(data_transfer[hapus][3])+"\n")
        nasabah.close()
        data_tf.close()
        data_ns.close()
        break
    else:
        print("Pilihan anda salah. Ulangi.")
